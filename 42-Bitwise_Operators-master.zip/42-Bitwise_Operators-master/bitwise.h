#ifndef BITWISE_H
# define BITWISE_H

#include <stdio.h>

/*
** Trick 1.4
*/

# define FLAG_A	1
# define FLAG_B	2
# define FLAG_C	4
# define FLAG_D	8

#endif