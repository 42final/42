### Day04 Solution File Names

ex00/ft_iterative_factorial.c <br>
ex01/ft_recursive_factorial.c <br>
ex02/ft_iterative_power.c <br>
ex03/ft_recursive_power.c <br>
ex04/ft_fibonacci.c <br>
ex05/ft_sqrt.c <br>
ex06/ft_is_prime.c <br>
ex07/ft_find_next_prime.c 

### Results 

ex00: OK | ex01: OK | ex02: OK | ex03: OK | ex04: OK | ex05: OK | ex06: KO | ex07: OK | ex08: Nothing turned in | ex09: Nothing turned in
