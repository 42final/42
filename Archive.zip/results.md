## Result list 

### Day 00 

ex01: OK | ex02: KO | ex03: OK | ex04: OK | ex05: KO | ex06: OK | ex07: OK | ex08: OK | ex09: OK | ex10: OK | ex11: OK

### Day 01 

ex01: OK | ex02: OK | ex03: OK | ex04: OK | ex05: OK | ex06: OK | ex07: OK | ex08: OK | ex09: OK

### Day 02 

ex00: OK | ex01: OK | ex02: OK | ex03: OK | ex04: OK | ex05: OK | ex06: OK | ex07: Norme error

### Day 03

ex00: OK | ex01: OK | ex02: OK | ex03: OK | ex04: OK | ex05: OK | ex06: OK | ex07: OK | ex08: OK | ex09: OK

### Day 04

ex00: OK | ex01: OK | ex02: OK | ex03: OK | ex04: OK | ex05: OK | ex06: KO | ex07: OK | ex08: Nothing turned in | ex09: Nothing turned in

### Day 05

ex00: OK | ex01: OK | ex02: OK | ex03: OK | ex04: OK | ex05: OK | ex06: OK | ex07: OK | ex08: OK | ex09: OK | ex10: OK | ex11: OK | ex12: OK | ex13: OK | ex14: OK | ex15: OK | ex16: KO | ex17: OK | ex18: OK | ex19: Does not compile | ex20: Nothing turned in | ex21: Nothing turned in | ex22: Nothing turned in | ex23: Nothing turned in

### Day 06

ex00: OK | ex01: OK | ex02: OK | ex03: OK | ex04: OK

### Day 07

ex00: OK | ex01: OK | ex02: OK | ex03: OK | ex04: OK | ex05: OK | ex06: Nothing turned in | ex07: Nothing turned in

### Day 08

ex00: OK | ex01: OK | ex02: OK | ex03: OK | ex04: OK | ex05: OK | ex06: Nothing turned in

### Day 09

ex00: Does not compile | ex01: OK | ex02: KO | ex03: OK | ex04: OK | ex05: OK | ex06: OK | ex07: OK | ex08: KO | ex09: KO | ex10: OK | ex11: OK | ex12: OK | ex13: Nothing turned in | ex14: Nothing turned in | ex15: Nothing turned in | ex16: OK | ex17: Nothing turned in | ex18: Nothing turned in | ex19: Nothing turned in | ex20: OK | ex21: Nothing turned in | ex22: OK | ex23: Does not compile

### Day 10

ex00: OK | ex01: OK | ex02: OK | ex03: OK | ex04: OK | ex05: KO | ex06: Nothing turned in | ex07: Nothing turned in | ex08: Nothing turned in | ex09: Nothing turned in

### Day 11

ex00: OK | ex01: OK | ex02: OK | ex03: OK | ex04: OK | ex05: OK | ex06: OK | ex07: OK | ex08: OK | ex09: OK | ex10: OK | ex11: OK | ex12: Does not compile | ex13: Nothing turned in | ex14: Nothing turned in | ex15: Nothing turned in | ex16: Nothing turned in | ex17: Nothing turned in

### Day 12

ex00: OK | ex01: Does not compile | ex02: Nothing turned in | ex03: Nothing turned in | ex04: Nothing turned in

### Day 13

ex00: OK | ex01: OK | ex02: OK | ex03: OK | ex04: OK | ex05: OK | ex06: OK | ex07: Nothing turned in | ex08: Nothing turned in | ex09: Nothing turned in

***

### Rush 00 (125%)

Correct with bonus points.

### Rush 01 (0%)

Feedback from Evaluator - "Project gives a solution for a blank sudoku. Unfortunately that is a basic test and we have to stop there. Otherwise, your project solved difficult sudokus with ease and in a very timely manner. Make sure you handle your errors correctly and I'm sure you all will do well in the next rush project."

### Rush 02 (0%)

No Attempt.

***

### Individual Projects
  - Sastantua (0%)
  - Match-N-Match (100%)
  - EvalExpr
    * MOULINETTE 45 % [ex00: Segmentation fault]
    * Overall 60 %
    * see evalexpr readme for Pass/Fail test cases.
  
***

### Final Project 

BSQ - 100% <br>
basic_tests: OK | functional_tests: OK
