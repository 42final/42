### Day02 Solution File Names

ex00/ft_print_alphabet.c <br>
ex01/ft_print_reverse_alphabet.c <br>
ex02/ft_print_numbers.c <br>
ex03/ft_is_negative.c <br>
ex04/ft_print_comb.c <br>
ex05/ft_print_comb2.c <br>
ex06/ft_putnbr.c <br>
ex07/ft_print_combn.c 

### Results 

ex00: OK | ex01: OK | ex02: OK | ex03: OK | ex04: OK | ex05: OK | ex06: OK | ex07: Norme error
