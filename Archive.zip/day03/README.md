### Day03 Solution File Names

ex00/ft_ft.c <br>
ex01/ft_ultimate_ft.c <br>
ex02/ft_swap.c <br>
ex03/ft_div_mod.c <br>
ex04/ft_ultimate_div_mod.c<br>
ex05/ft_putstr.c<br>
ex06/ft_strlen.c<br>
ex07/ft_strrev.c<br>
ex08/ft_atoi.c<br>
ex09/ft_sort_integer_table.c

### Results

ex00: OK | ex01: OK | ex02: OK | ex03: OK | ex04: OK | ex05: OK | ex06: OK | ex07: OK | ex08: OK | ex09: OK
