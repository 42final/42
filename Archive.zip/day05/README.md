### Day05 Solution File Names

ex00/ft_putstr.c <br>
ex01/ft_putnbr.c <br>
ex02/ft_atoi.c <br>
ex03/ft_strcpy.c <br>
ex04/ft_strncpy.c <br>
ex05/ft_strstr.c <br>
ex06/ft_strcmp.c <br>
ex07/ft_strncmp.c <br>
ex08/ft_strupcase.c<br>
ex09/ft_strlowcase.c<br>
ex10/ft_strcapitalize.c<br>
ex11/ft_str_is_alpha.c<br>
ex12/ft_str_is_numeric.c<br>
ex13/ft_str_is_lowercase.c<br>
ex14/ft_str_is_uppercase.c<br>
ex15/ft_str_is_printable.c<br>
ex16/ft_strcat.c<br>
ex17/ft_strncat.c<br>
ex18/ft_strlcat.c<br>
ex19/ft_strlcpy

### Results 

ex00: OK | ex01: OK | ex02: OK | ex03: OK | ex04: OK | ex05: OK | ex06: OK | ex07: OK | ex08: OK | ex09: OK | ex10: OK | ex11: OK | ex12: OK | ex13: OK | ex14: OK | ex15: OK | ex16: KO | ex17: OK | ex18: OK | ex19: Does not compile | ex20: Nothing turned in | ex21: Nothing turned in | ex22: Nothing turned in | ex23: Nothing turned in
